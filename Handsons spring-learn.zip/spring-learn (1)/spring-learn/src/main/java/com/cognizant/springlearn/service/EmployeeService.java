package com.cognizant.springlearn.service;

import java.beans.Transient;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.springlearn.dao.EmployeeDao;
import com.cognizant.springlearn.model.Employee;

@Service
public class EmployeeService {
	@Autowired
	EmployeeDao employeeDao;
	
	@Transient
	public ArrayList<Employee> getAllEmployees()
	{
		ArrayList<Employee> employeeList= employeeDao.getAllEmployees();
		return  employeeList;
		
	}
	public ArrayList<Employee> updateEmployees()
	{
		return null;
		
	}

}
