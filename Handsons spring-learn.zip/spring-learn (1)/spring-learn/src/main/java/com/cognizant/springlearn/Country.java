package com.cognizant.springlearn;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Country {
		 private static final Logger LOGGER = LoggerFactory.getLogger(SpringLearnApplication.class);
		    @NotBlank
		    @Size(min=2,max=2,message="Country code shoud be 2 characters")
		    public String code;
		    private String name;
		 
		    public Country() {
		        LOGGER.info("Country -Default Constructor");
		    }
		 
		    public Country(String code, String name) {
				super();
				this.code = code;
				this.name = name;
			}

			public String getCode() {
		        LOGGER.debug("Getter Method : Code = {}",code);
		        return code;
		    }

			public String getName() {
				return name;
			}

			public void setName(String name) {
				this.name = name;
			}

			public void setCode(String code) {
				this.code = code;
			}

			@Override
			public String toString() {
				return "Country [code=" + code + ", name=" + name + "]";
			}
		    
		
	}
