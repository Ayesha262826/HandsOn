package com.cognizant.springlearn.service;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.cognizant.springlearn.Country;
import com.cognizant.springlearn.service.exception.CountryNotFoundException;

@Service
public class CountryService {
	private static ArrayList<Country> countryList;

	public CountryService() {
    ApplicationContext context= new ClassPathXmlApplicationContext("country.xml");
    countryList=(ArrayList<Country>) context.getBean("countryList");
	}

	public Country getCountry(String code) throws CountryNotFoundException {
		//ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
		//List<Country> countryList = (List<Country>) context.getBean("countryList");
		
		 Country cou=countryList.stream().filter(coun->(coun.code).equalsIgnoreCase(code)).findFirst().orElse(null);
		return cou;
	}

	public ArrayList<Country> getAllCountries() {
		// TODO Auto-generated method stub
		return countryList;
	}

	public void addCountry(Country country) {
		boolean isExist=false;
		for(Country coun:countryList) {
			if(coun.getCode()==country.getCode()) {
				isExist=true;
				break;
			}
		}
		boolean isAdded=false;
		if(isExist==false) {
			countryList.add(country);
			isAdded=true;
		}
		//return isAdded;
	}
}