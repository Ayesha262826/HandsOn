package com.cognizant.springlearn.controller;

import java.util.ArrayList;

import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.cognizant.springlearn.Country;
import com.cognizant.springlearn.SpringLearnApplication;
import com.cognizant.springlearn.service.CountryService;
import com.cognizant.springlearn.service.exception.CountryNotFoundException;

@RestController

public class CountryController {
	private static final Logger LOGGER =LoggerFactory.getLogger(CountryController.class);

	@Autowired
    CountryService countryService;


	@RequestMapping("/country")
	public Country getCountryIndia() {
		ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
		Country country = (Country) context.getBean("country", Country.class);
		//Country anotherCountry = context.getBean("country", Country.class);
		return country;
	}

	@RequestMapping("/countries")
	public ArrayList<Country> getAllCountries() {
		//ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
	//	List<Country> countryList = (List<Country>) context.getBean("countryList");
		return countryService.getAllCountries();
	}
	
	@GetMapping("/countries/{code}") // path variable
	public ResponseEntity<Object> getCountry(@PathVariable("code") String code) throws CountryNotFoundException {
		Country coun = countryService.getCountry(code);
		ResponseEntity<Object> entity = new ResponseEntity<Object>(coun, HttpStatus.OK);
		if (coun == null) {
			entity = new ResponseEntity<Object>("Not Found", HttpStatus.NO_CONTENT);
		}
	   return entity;
	}
	   @PostMapping(path="/countries",consumes="application/json",produces="application/json")
	//@PostMapping("/countries")
    public Country addCountry(@RequestBody @Valid Country country)
    {
    	LOGGER.info("Start");
    	ValidatorFactory factory=Validation.buildDefaultValidatorFactory();
    	Validator validator=factory.getValidator();
    	Set<ConstraintViolation<Country>> violations=validator.validate(country);
    	List<String> errors=new ArrayList<>();
    	for(ConstraintViolation<Country> violation : violations)
    	{
    		errors.add(violation.getMessage());
    	}
    	if(violations.size()>0)
    	{
    		throw new ResponseStatusException(HttpStatus.BAD_REQUEST,errors.toString());
    	}
       LOGGER.info("End");
	   countryService.addCountry(country);
      return country;
	}

}
