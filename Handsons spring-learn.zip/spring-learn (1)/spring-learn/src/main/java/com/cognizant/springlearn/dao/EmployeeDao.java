package com.cognizant.springlearn.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cognizant.springlearn.model.Employee;
@Component
public class EmployeeDao {
  public static ArrayList<Employee> employeeList;
  public ArrayList<Employee> getAllEmployees()
  {
	  ApplicationContext context= new ClassPathXmlApplicationContext("employee.xml");
	  ArrayList<Employee> employeeList=(ArrayList<Employee>) context.getBean("empList");
	  return employeeList;
  }
  public ArrayList<Employee> updateEmployee() throws ClassNotFoundException
  {
	  
	  return employeeList;
  }
}
