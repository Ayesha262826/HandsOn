package com.cognizant.springlearn.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cognizant.springlearn.model.Department;
@Component
public class DepartmentDao {
		  public List<Department> departmentList;
		  public static List<Department> getAllDepartments()
		  {
		  ApplicationContext context= new ClassPathXmlApplicationContext("employee.xml");
		  List<Department> departmentList=(List<Department>) context.getBean("deptList");
		return departmentList;
	}
	
	}


